# Dr.Fabs — SiteOne Crawler on GitHub Actions

This runs SiteOne Crawler on a GitHub-hosted Ubuntu runner, not on your Windows PC.
It creates HTML, JSON and TXT reports for `https://fabrockers.com`.

## Setup

1. Create a **new public GitHub repository** (example: `drfabs-site-audit`).
   - Public is required here to use standard GitHub-hosted runner compute without charge.
   - Do not upload credentials, customer data, or private source code to this repository.
2. In the new repository, create this exact path:
   `.github/workflows/siteone-crawl.yml`
3. Paste the contents of `siteone-crawl.yml` from this package and commit it to the `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Dr.Fabs Full-Site Crawl** in the left sidebar.
6. Click **Run workflow**. Keep the default URL and page cap for the first run.
7. Open the completed workflow run. Under **Artifacts**, download
   `drfabs-siteone-crawl-reports`.

## Reports

- `drfabs-full-site-report.html` — interactive audit report
- `drfabs-full-site-data.json` — structured crawl data
- `drfabs-full-site-summary.txt` — text summary

## Important notes

- This uses a standard `ubuntu-24.04` GitHub-hosted runner. GitHub currently lists
  16 GB RAM for standard public-repository Ubuntu runners and says standard
  runner use is free and unlimited for public repositories. See:
  https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- The repository must be public for the free standard hosted-runner arrangement.
  The workflow file and logs are public. Do not put secrets in it.
- GitHub artifact storage/retention limits still apply. This workflow retains
  the report artifact for 7 days; download it after the run.
- SiteOne respects robots.txt by default. Do not add `--ignore-robots-txt`
  unless you have a specific, legitimate reason and permission.
- The default crawl follows discoverable links. It cannot guarantee every URL
  if pages are orphaned, blocked by robots.txt, behind login, or absent from
  links/sitemaps. For best coverage, ensure the site's sitemap is current.
- The page cap is set to 25,000 to allow for more than the ~8,041 URLs seen in
  the earlier desktop crawl. Change it in the Run workflow form if needed.
- The workflow uses file-backed result storage to reduce RAM pressure.
- This first workflow does not enable full Chromium rendering on every page.
  If the website relies on client-side JavaScript for discoverable links/content,
  run a separate browser-rendered audit after the first crawl.
- Do not repeatedly run the crawler at high concurrency. Defaults here are
  deliberately modest (3 workers, 5 requests/second).

## Official references

- SiteOne CLI usage: https://crawler.siteone.io/getting-started/basic-usage/
- SiteOne CLI options: https://crawler.siteone.io/configuration/command-line-options/
- GitHub runner specifications: https://docs.github.com/en/actions/reference/runners/github-hosted-runners
- GitHub Actions billing: https://docs.github.com/en/actions/concepts/billing-and-usage
